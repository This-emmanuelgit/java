package test;

class test3 {
	void display(int i) {
		System.out.println(i);
	}

	void display(int i, String j) {
		System.out.println(i + j);
	}

	void display(String i) {
		System.out.println(i);
	}
}

public class test2 extends test3 {
	void display(String i) {
		System.out.println(i + " subclass");
	}

	public static void main(String[] args) {
		test2 t = new test2();
		t.display(1);
		t.display(1, "joy");
		t.display("emmanuel");
	}
}
