package test;

class Bike {
	int speedlimit = 90;
}

class sdg extends Bike {
	int speedlimit = 150;

	public static void main(String args[]) {
		sdg obj = new sdg();
		System.out.println(obj.speedlimit);// 90
	}
}
