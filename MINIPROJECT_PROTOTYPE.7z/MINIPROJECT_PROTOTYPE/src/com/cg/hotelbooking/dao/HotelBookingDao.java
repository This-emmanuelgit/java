package com.cg.hotelbooking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HotelBookingDao {

	public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			con = DriverManager.getConnection(url, user, pass);
			return con;

		} catch (Exception e) {

			//e.printStackTrace();

		}

		return con;

	}
	public boolean addHotelDescription(String hotelid, String desc) {
		boolean result=false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select description from Hotel where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, hotelid);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				String str=rs.getString(1);
				String str1=str+". "+desc;
				PreparedStatement ps1 = null;
				Connection con1 = getConnection();
				String sql1 = "update Hotel set description=? where hotel_id=?";
				try {
						ps1 = con1.prepareStatement(sql1);
						ps1.setString(1, str1);
						ps1.setString(2, hotelid);
						try {
							int r=ps1.executeUpdate();
							result=true;
							return result;
							}
						catch(Exception e){
							//couldnt update description possible reason..description size crossed
							e.printStackTrace();
							return result;
							}
					}

					catch (Exception e) {
						//No connection
						e.printStackTrace();
						return result;		
					}
				}

				catch (Exception e) {
					//No hotel id
					e.printStackTrace();
					return result;
				}
		
			}
		catch(Exception e)
		{
			//No connection
			e.printStackTrace();
			return result;		
		}

	}
	public boolean updateHotelDescription(String hotelid, String desc) {
		boolean result=false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "update Hotel set description=? where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, desc);
			ps.setString(2,hotelid);
		
			try {
					int r=ps.executeUpdate();
					result=true;
					return result;
				}
			catch(Exception e){
							//couldnt update description possible reason..description size crossed
					e.printStackTrace();
					return result;
				}
		
			}
		catch(Exception e)
		{
			//No connection
			e.printStackTrace();
			return result;		
		}

	}
}

