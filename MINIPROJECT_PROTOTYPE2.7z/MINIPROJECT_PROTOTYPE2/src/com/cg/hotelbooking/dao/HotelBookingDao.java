package com.cg.hotelbooking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HotelBookingDao {

	public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			con = DriverManager.getConnection(url, user, pass);
			return con;

		} catch (Exception e) {

			//e.printStackTrace();

		}

		return con;

	}
	public boolean addHotelDescription(String hotelid, String desc) {
		boolean result=false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select description from Hotel where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, hotelid);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				String str=rs.getString(1);
				String str1=str+". "+desc;
				PreparedStatement ps1 = null;
				Connection con1 = getConnection();
				String sql1 = "update Hotel set description=? where hotel_id=?";
				try {
						ps1 = con1.prepareStatement(sql1);
						ps1.setString(1, str1);
						ps1.setString(2, hotelid);
						try {
							int r=ps1.executeUpdate();
							result=true;
							return result;
							}
						catch(Exception e){
							//couldnt update description possible reason..description size crossed
							e.printStackTrace();
							return result;
							}
					}

					catch (Exception e) {
						//No connection
						e.printStackTrace();
						return result;		
					}
				}

				catch (Exception e) {
					//No hotel id
					e.printStackTrace();
					return result;
				}
		
			}
		catch(Exception e)
		{
			//No connection
			e.printStackTrace();
			return result;		
		}

	}
	public boolean updateHotelDescription(String hotelid, String desc) {
		boolean result=false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "update Hotel set description=? where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, desc);
			ps.setString(2,hotelid);
		
			try {
					int r=ps.executeUpdate();
					result=true;
					return result;
				}
			catch(Exception e){
							//couldnt update description possible reason..description size crossed
					e.printStackTrace();
					return result;
				}
		
			}
		catch(Exception e)
		{
			//No connection
			e.printStackTrace();
			return result;		
		}

	}
	public boolean deleteHotelDescription(String hotelid) {
		boolean result=false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "update Hotel set description=' ' where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, hotelid);
			try {
					ps.executeUpdate();
					result=true;
					return result;
				}
			catch(Exception e){
							//couldnt update description possible reason..description size crossed
					e.printStackTrace();
					return result;
				}
		
			}
		catch(Exception e)
		{
			//No connection
			e.printStackTrace();
			return result;		
		}
	}
	
	public int userCustomerBookRoom(String hotelid, String roomid,String noofadults, String noofchildren, String bookingdate,String noofdaysofstay, String usercustomermobileno, String roomrate) {
		int status=0;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select user_id from Users where mobile_no=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, usercustomermobileno);
			ResultSet rs = null;
			try {
					rs=ps.executeQuery();
					rs.next();
					String userid=rs.getString(1);
					double amnt= ( (Integer.parseInt(roomrate)*Integer.parseInt(noofadults) ) + ( (0.5*(Integer.parseInt(roomrate)))*Integer.parseInt(noofchildren)) );
					String amount=String.valueOf(amnt);
					PreparedStatement ps1 = null;
					Connection con1 = getConnection();
					String sql1 = "insert into BookingDetails values(bookingid.NEXTVAL,?,?,TO_DATE(?,'dd-mm-yyyy'),TO_DATE(?,'dd-mm-yyyy')+?,?,?,?)";
					try {
						ps1 = con1.prepareStatement(sql1);
						ps1.setString(1, roomid);
						ps1.setString(2, userid);
						ps1.setString(3, bookingdate);
						ps1.setString(4, bookingdate);
						ps1.setInt(5, Integer.parseInt(noofdaysofstay));
						ps1.setString(6, noofadults);
						ps1.setString(7, noofchildren);
						ps1.setString(8, amount);
						try{
							ps1.executeUpdate();
							status=1;
							return status;
							}
						catch(Exception e){
							
							return status;
							}
						}
					catch(Exception e)
						{
							e.printStackTrace();
							return status;
						}
				}
				catch(Exception e){
							
					status=2;
					return status;
				}
		
			}
		catch(Exception e)
		{
			//No connection
			e.printStackTrace();
			return status;		
		}
	}
}

