package com.cg.hbms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.dao.HotelBookingDao;


@WebServlet("/ForgotPassword")
public class ForgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String user_name = request.getParameter("user_name");
		String password = request.getParameter("password");
		String confirmpassword = request.getParameter("confirmpassword");
		HotelBookingDao dao=new HotelBookingDao();
		
		int n = dao.forgotpassword(user_name,password,confirmpassword);
		
		if (n>0 && password.equals(confirmpassword)) {
		out.println("Successfully updated password for username"+ user_name);
		RequestDispatcher rd = request.getRequestDispatcher("Customer.jsp");
		rd.include(request, response);
		} 
		
		else 
		{
		out.println("no such username found...Please register.. ");
		RequestDispatcher rd = request.getRequestDispatcher("Register.jsp");
		rd.include(request, response);
		}
		}
		}
