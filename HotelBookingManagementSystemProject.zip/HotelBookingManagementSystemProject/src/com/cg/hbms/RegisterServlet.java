package com.cg.hbms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.dao.HotelBookingDao;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HotelBookingDao dao=new HotelBookingDao();

		response.setContentType("text/html");

		PrintWriter out = response.getWriter();
  
		String user_name = request.getParameter("user_name");
		String password = request.getParameter("password");
		String role = request.getParameter("role");

		String mobile_no =request.getParameter("mobile_no");
		String address = request.getParameter("address");
		String email= request.getParameter("email");

		int n = dao.add(user_name, password,role, mobile_no, address,email);
if(n>0)
		{

		out.println("Successfully added user");
RequestDispatcher rd=request.getRequestDispatcher("CustomerLogin.jsp");
		rd.include(request,response);
		}

		else

		{

		out.println("Not inserted ..try after some time");

		}

		}


}


