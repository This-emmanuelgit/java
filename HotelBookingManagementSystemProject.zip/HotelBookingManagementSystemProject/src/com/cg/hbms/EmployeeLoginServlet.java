package com.cg.hbms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.dao.HotelBookingDao;

@WebServlet("/employee")
public class EmployeeLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");	
		PrintWriter out=response.getWriter();
		String user_name=request.getParameter("user_name");
		String password=request.getParameter("password");	
		HotelBookingDao dao=new HotelBookingDao();
		
		boolean flag=dao.evalidate(user_name,password);
		if(flag){
		RequestDispatcher rd=request.getRequestDispatcher("user_customer_view_hotellist.jsp");
			rd.forward(request, response);
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("Home.jsp?emsg=username/password is invalid");
			rd.include(request,response);
		}
	}



	}


