package com.cg.hbms;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.dao.HotelBookingDao;

/**
 * Servlet implementation class CheckSpecificDate
 */
@WebServlet("/checkdate")
public class CheckSpecificDate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HotelBookingDao dao = new HotelBookingDao();
		int j=1;
		PrintWriter out = response.getWriter();
		List<String> list=new ArrayList<String>(),list2=new ArrayList<String>();
		response.setContentType("text/html");
		String booked_from=request.getParameter("date");
		 list=dao.checkofspecificdate(booked_from);
		 
		if(!list.isEmpty())
		{
			
			for(int i=0;i<list.size();i++)
			{
				if(i==(list.size()-1))
				{
					list2.add(list.get(i));
					list2.add(String.valueOf(j));
					break;
				}
				if (list.get(i).equals(list.get(i+1)))
				{
					j++;
				}
				else
				{
					list2.add(list.get(i));
					list2.add(String.valueOf(j));
					j=1;
				}
			}
			
				out.println("<!DOCTYPE html>");
				out.println("<html>");
				out.println("<head><title>Booking On Specified Date</title></head>");
				out.println("<body>");
				out.println("<table border='1'>");
				out.println("<tr><th>Hotel Name</th><th>Number Of bookings</th></tr>");
				for(int i=0;i<list2.size();i+=2)
				{
					if(i==(list2.size()))
						break;
					out.println("<tr><td>"+list2.get(i)+"</td><td>"+list2.get(i+1)+"</td></tr>");
				}
				out.println("</table>");
				out.println("</body>");
				out.println("</html>");
		}
		 
		else
		{
			out.println("No bookings on this date");
//			RequestDispatcher rd = request.getRequestDispatcher("user_customer_view_hotellist.jsp");
//			rd.include(request, response);
		}
	}

}
