package com.cg.hbms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.dao.HotelBookingDao;


/**
 * Servlet implementation class UserCustomerBookRoom
 */
@WebServlet("/book")
public class UserCustomerBookRoom extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HotelBookingDao dao = new HotelBookingDao();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String hotelid=request.getParameter("hotelid");
		String roomid=request.getParameter("roomid");
		String roomrate=request.getParameter("roomrate");
		String noofadults=request.getParameter("noofadults");
		String noofchildren=request.getParameter("noofchildren");
		String bookingdate=request.getParameter("bookingdate");
		String noofdaysofstay=request.getParameter("noofdaysofstay");
		String usercustomermobileno=request.getParameter("usercustomermobileno");
		int[] status=dao.userCustomerBookRoom(hotelid,roomid,noofadults,noofchildren,bookingdate,noofdaysofstay,usercustomermobileno,roomrate);
		if(status[0]==1)
		{
			out.println("Succesfully booked with booking id :"+status[1]);
			RequestDispatcher rd = request.getRequestDispatcher("user_customer_view_hotellist.jsp");
			rd.include(request, response);
		}
		else if(status[0]==2)
		{
			out.println("Not a registered Mobile Number");
			RequestDispatcher rd = request.getRequestDispatcher("bookroom.jsp?roomid="+roomid+"&&hotelid="+hotelid+"&&roomrate="+roomrate);
			rd.include(request, response);
		}
	}

}
