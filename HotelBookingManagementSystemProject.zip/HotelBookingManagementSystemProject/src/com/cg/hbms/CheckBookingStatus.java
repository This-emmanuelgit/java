package com.cg.hbms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.dao.HotelBookingDao;

/**
 * Servlet implementation class CheckBookingStatus
 */
@WebServlet("/bookingstatus")
public class CheckBookingStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HotelBookingDao dao = new HotelBookingDao();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String bookingid=request.getParameter("bookingid");
		String[] details=dao.checkBookingStatusUser(bookingid);
		if(details.length!=0)
		{
			out.println("Your Booking at Hotel "+details[3]+" at Room number "+details[0]+" from "+details[1]+" to "+details[2]+" is confirmed..Enjoy Your Stay!\n\n");
			RequestDispatcher rd = request.getRequestDispatcher("user_customer_view_hotellist.jsp");
			rd.include(request, response);
			
		}
		else
		{
			out.println("Invalid Booking id!");
			RequestDispatcher rd = request.getRequestDispatcher("user_customer_view_hotellist.jsp");
			rd.include(request, response);
		}
	}

}
