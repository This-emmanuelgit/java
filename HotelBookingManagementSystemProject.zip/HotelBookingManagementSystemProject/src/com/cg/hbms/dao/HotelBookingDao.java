package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class HotelBookingDao {
	Connection con = null;
	PreparedStatement ps = null;

	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";

			con = DriverManager.getConnection(url, user, pass);
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public int add(String user_name, String password, String role,
			String mobile_no, String address, String email) {
		con = getConnection();
		String sql = "insert into Users values(userid.nextval,?,'customer',?,?,?,?,?)";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, password);
			ps.setString(2, user_name);
			ps.setString(3, mobile_no);

			ps.setString(4, mobile_no);
			ps.setString(5, address);
			ps.setString(6, email);

			int n = ps.executeUpdate();
			return n;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int forgotpassword(String user_name, String password,
			String confirmpassword) {
		con = getConnection();
		String sql = "update Users set password=? where user_name=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(2, user_name);
			ps.setString(1, password);
			int n = ps.executeUpdate();
			return n;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public boolean validate(String user_name, String password) {
		con = getConnection();
		String sql = "select role from Users where user_name=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, user_name);
			ResultSet rs = ps.executeQuery();
			rs.next();
			System.out.println(rs.getString(1));
			return true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;

	}

	public boolean addHotelDescription(String hotelid, String desc) {
		boolean result = false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select description from Hotel where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, hotelid);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				String str = rs.getString(1);
				String str1 = str + ". " + desc;
				PreparedStatement ps1 = null;
				Connection con1 = getConnection();
				String sql1 = "update Hotel set description=? where hotel_id=?";
				try {
					ps1 = con1.prepareStatement(sql1);
					ps1.setString(1, str1);
					ps1.setString(2, hotelid);
					try {
						int r = ps1.executeUpdate();
						result = true;
						return result;
					} catch (Exception e) {
						// couldnt update description possible
						// reason..description size crossed
						e.printStackTrace();
						return result;
					}
				}

				catch (Exception e) {
					// No connection
					e.printStackTrace();
					return result;
				}
			}

			catch (Exception e) {
				// No hotel id
				e.printStackTrace();
				return result;
			}

		} catch (Exception e) {
			// No connection
			e.printStackTrace();
			return result;
		}

	}

	public boolean updateHotelDescription(String hotelid, String desc) {
		boolean result = false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "update Hotel set description=? where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, desc);
			ps.setString(2, hotelid);

			try {
				int r = ps.executeUpdate();
				result = true;
				return result;
			} catch (Exception e) {
				// couldnt update description possible reason..description size
				// crossed
				e.printStackTrace();
				return result;
			}

		} catch (Exception e) {
			// No connection
			e.printStackTrace();
			return result;
		}

	}

	public boolean deleteHotelDescription(String hotelid) {
		boolean result = false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "update Hotel set description=' ' where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, hotelid);
			try {
				ps.executeUpdate();
				result = true;
				return result;
			} catch (Exception e) {
				// could nt update description possible reason..description size
				// crossed
				e.printStackTrace();
				return result;
			}

		} catch (Exception e) {
			// No connection
			e.printStackTrace();
			return result;
		}
	}

	public int[] userCustomerBookRoom(String hotelid, String roomid,
			String noofadults, String noofchildren, String bookingdate,
			String noofdaysofstay, String usercustomermobileno, String roomrate) {
		int[] status = new int[2];
		status[0] = 0;
		status[1] = 0;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select user_id from Users where mobile_no=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, usercustomermobileno);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				String userid = rs.getString(1);
				double amnt = ((Integer.parseInt(roomrate) * Integer
						.parseInt(noofadults)) + ((0.5 * (Integer
						.parseInt(roomrate))) * Integer.parseInt(noofchildren)));
				String amount = String.valueOf(amnt);
				PreparedStatement ps1 = null;
				Connection con1 = getConnection();
				String sql1 = "insert into BookingDetails values(bookingid.NEXTVAL,?,?,TO_DATE(?,'dd-mm-yyyy'),TO_DATE(?,'dd-mm-yyyy')+?,?,?,?)";
				try {
					ps1 = con1.prepareStatement(sql1);
					ps1.setString(1, roomid);
					ps1.setString(2, userid);
					ps1.setString(3, bookingdate);
					ps1.setString(4, bookingdate);
					ps1.setInt(5, Integer.parseInt(noofdaysofstay));
					ps1.setString(6, noofadults);
					ps1.setString(7, noofchildren);
					ps1.setString(8, amount);
					try {
						ps1.executeUpdate();
						PreparedStatement ps2 = null;
						Connection con2 = getConnection();
						String sql2 = "update RoomDetails set availability=0 where room_id=?";
						PreparedStatement ps3 = null;
						String sql3 = "select booking_id from BookingDetails where room_id=?";
						try {
							ps2 = con2.prepareStatement(sql2);
							ps2.setString(1, roomid);
							ps3 = con2.prepareStatement(sql3);
							ps3.setString(1, roomid);
							ResultSet rs3 = null;

							try {
								ps2.executeUpdate();
								rs3 = ps3.executeQuery();
								rs3.next();
								status[1] = Integer.parseInt(rs3.getString(1));
							} catch (Exception e) {
								e.printStackTrace();
							}
						} catch (Exception e) {
							// No connection
							e.printStackTrace();
						}

						status[0] = 1;
						return status;
					} catch (Exception e) {

						return status;
					}
				} catch (Exception e) {
					e.printStackTrace();
					return status;
				}
			} catch (Exception e) {

				status[0] = 2;
				return status;
			}

		} catch (Exception e) {
			// No connection
			e.printStackTrace();
			return status;
		}
	}

	public boolean bookingsofspecifichotels(String hotelid) {

		boolean result = false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select count(booking_id) where hotel_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, hotelid);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				result = true;
				return result;
			} catch (Exception e) {
				// couldnt update description possible reason..description size
				// crossed
				e.printStackTrace();
				return result;
			}

		} catch (Exception e) {
			// No connection
			e.printStackTrace();
			return result;
		}
	}

	public String[] checkBookingStatusUser(String bookingid) {
		String[] temp = new String[7];
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select * from BookingDetails where booking_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, bookingid);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				temp[0] = rs.getString(2);
				temp[1] = rs.getString(4);
				temp[2] = rs.getString(5);
				PreparedStatement ps1 = null;
				String sql2 = "select hotel_id from Roomdetails where room_id=?";
				ps1 = con.prepareStatement(sql2);
				//System.out.println(rs.getString(2));
				ps1.setString(1, rs.getString(2));
				ResultSet rs1 = null;
				rs1 = ps1.executeQuery();
				rs1.next();
				PreparedStatement ps2 = null;
				String sql3 = "select hotel_name from Hotel where hotel_id=?";
				ps2 = con.prepareStatement(sql3);
				System.out.println(rs1.getString(1));
				ps2.setString(1, rs1.getString(1));
				ResultSet rs2 = null;
				rs2 = ps2.executeQuery();
				rs2.next();
				temp[3] = rs2.getString(1);
				return temp;
			} catch (Exception e) {
				// couldnt update description possible reason..description size
				// crossed
				e.printStackTrace();
				return temp;
			}

		} catch (Exception e) {
			// No connection
			e.printStackTrace();
			return temp;
		}
	}

	public List<String> checkofspecificdate(String booked_from) {
		List<String> list= new ArrayList<String>();
		int i=1,k=0;
		String temp=" ";
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select room_id from BookingDetails where booked_from=TO_DATE(?,'dd-mm-yyyy')";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, booked_from);

			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				while (rs.next()) {
					
				
					PreparedStatement ps1 = null;
					
					String sql2 = "select hotel_id from RoomDetails where room_id=?";
					ps1 = con.prepareStatement(sql2);
					ps1.setString(1, rs.getString(1));
					
					ResultSet rs1 = null;
					rs1 = ps1.executeQuery(); 
					rs1.next();
					
				
					String sql3 = "select hotel_name from Hotel where hotel_id=?";
					PreparedStatement ps2 = null;
					ps2 = con.prepareStatement(sql3);
					ps2.setString(1, rs1.getString(1));
					//System.out.println( rs1.getString(1));
					ResultSet rs2 = null;
					rs2 = ps2.executeQuery();
					rs2.next();
					list.add(rs2.getString(1));
				}
				return list;
			} catch (Exception e) {

				e.printStackTrace();
				return list;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return list;
		}
	}

	public boolean cvalidate(String user_name, String password) {
		boolean result = false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select password from Users where user_name=? and role='customer'";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, user_name);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				if(password.equals(rs.getString(1)))
				{
				result = true;
				}
				return result;
			} catch (Exception e) {
				return result;
			}

		} catch (Exception e) {
			// No connection
			e.printStackTrace();
			return result;
		}
	}

	public boolean evalidate(String user_name, String password) {
		boolean result = false;
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select password from Users where user_name=? and role='employee'";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, user_name);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				if(password.equals(rs.getString(1)))
				{
				result = true;
				}
				return result;
			} catch (Exception e) {
				return result;
			}

		} catch (Exception e) {
			// No connection
			e.printStackTrace();
			return result;
		}
	}

}
