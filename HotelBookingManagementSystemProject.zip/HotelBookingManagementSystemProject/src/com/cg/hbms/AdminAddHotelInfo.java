package com.cg.hbms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.dao.HotelBookingDao;



/**
 * Servlet implementation class AdminAddHotelInfo
 */
@WebServlet("/adddescription")
public class AdminAddHotelInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HotelBookingDao dao = new HotelBookingDao();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String hotelid=request.getParameter("hotelid");
		String desc=request.getParameter("addedhoteldescription");
		if(dao.addHotelDescription(hotelid,desc))
		{
			out.println("Succesfully added Description");
			RequestDispatcher rd = request.getRequestDispatcher("adminviewhotels.jsp");
			rd.include(request, response);
		}
		else
		{
			out.println("Error occured ..Try again later");
		}
	}

}
