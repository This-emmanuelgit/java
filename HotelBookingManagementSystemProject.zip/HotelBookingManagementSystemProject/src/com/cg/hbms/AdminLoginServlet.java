package com.cg.hbms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.dao.HotelBookingDao;

@WebServlet("/admin")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");	
		PrintWriter out=response.getWriter();
		String user_name=request.getParameter("user_name");
		String password=request.getParameter("password");		
		if(user_name.equals("niharika") && password.equals("11111")){
		RequestDispatcher rd=request.getRequestDispatcher("adminoptions.jsp");
			//response.sendRedirect("home.jsp");
			rd.forward(request, response);
		}
		else{
			
			out.println("username/password is invalid");
			RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
			rd.include(request,response);
		}
	}

}
