

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: StaffMembers
 *
 */
@Entity
@Table(name="StaffData")

public class StaffMembers implements Serializable {

	   
	@Id
	private int staffRoll;
	private String staffName;
	private double staffSalary;
	private static final long serialVersionUID = 1L;

	public StaffMembers() {
		super();
	}   
	public int getStaffRoll() {
		return this.staffRoll;
	}

	public void setStaffRoll(int staffRoll) {
		this.staffRoll = staffRoll;
	}   
	public String getStaffName() {
		return this.staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}   
	public double getStaffSalary() {
		return this.staffSalary;
	}

	public void setStaffSalary(double staffSalary) {
		this.staffSalary = staffSalary;
	}
   
}
