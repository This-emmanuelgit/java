import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class StaffPersist {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("testofjpa");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		StaffMembers sm = new StaffMembers();
		sm.setStaffRoll(1001);
		sm.setStaffName("Emmanuel Joy");
		sm.setStaffSalary(20000.0);
		em.persist(sm);
		em.getTransaction().commit();
		em.close();
		emf.close();

	}

}
