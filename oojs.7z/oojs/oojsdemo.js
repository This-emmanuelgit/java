var person = {
  name: ['Emmanuel', 'Joy'],
  age: 21,
  gender: 'male',
  interests: ['music', 'Guitar'],
  bio: function() {
    alert(this.name[0] + ' ' + this.name[1] + ' is ' + this.age + ' years old. He likes ' + this.interests[0] + ' and ' + this.interests[1] + '.');
  },
  greeting: function() {
    alert('Hi! I\'m ' + this.name[0] + '.');
	
  }
}
var myDataName = 'height';
var myDataValue = '1.75m';
person[myDataName] = myDataValue;
document.write(person.name);
document.write(person.bio());