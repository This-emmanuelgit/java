let firstName;
let lastName;

let User={
		
		set firstname(name){
		this.firstName=name;
		},
		set lastname(name){
		this.lastName=name;
		},
		get fullname(){
			return this.firstName+" "+this.lastName;
		}

}
User.firstname='Emmanuel';
User.lastname="Joy";
document.write(User.fullname);