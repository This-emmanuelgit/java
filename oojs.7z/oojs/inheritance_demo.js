let person ={
	name:'Joy',
	display(){
		document.write("Hello "+this.name+"!");
	}
}
let employee={
	salary:99000,
	name:'Emmanuel',
	print() {
	
		document.write("Your salary:"+this.salary);
	},
	display(){
		document.write("Hi "+name+"!");
	}
}

employee.__proto__=person;
employee.display();
employee.print();


var emp={
id:1,name:'Emmanuel',city:'Hyderabad'
}

var json=JSON.stringify(emp);
document.write(emp);