let firstname;
let lastname;
firstname='Emmanuel';
lastname='Joy';
let customer={
	display() {
	confirm("This is a customer class display method");}

}
customer.display();
//defining userdefined class
function user(){}
user.prototype.sayHello =()=>{
alert("This is a user method says hello without params")
}
var u=new user();
u.sayHello();
let Student={
	displayFLName()
	{
		confirm("Hi Mr."+firstname+" "+lastname+" Please confirm your name  ");
	}
}
Student.displayFLName();
function student(){}
student.prototype.greetings =(firstname,lastname)=>{
confirm(" 2.Hi Mr."+firstname+" "+lastname+" Please confirm your name  ");
}
var s= new student();
s.greetings();